<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class estiloLanding extends Model
{
    //
protected $table = "estilo_landing";

}
