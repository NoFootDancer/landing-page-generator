<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class contactoLanding extends Model
{
    //
    protected $table = "contacto_landing";
    public $timestamps = false;
}
